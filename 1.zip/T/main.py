import atexit
import html
import io
import logging
import os
import re
import sqlite3
import threading
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import httpx
from dotenv import load_dotenv
from openpyxl import load_workbook
from PIL import Image, ImageDraw, ImageFont
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, InputFile, Update
from telegram.constants import ParseMode
from telegram.error import Conflict, TelegramError
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)


BASE_DIR = Path(__file__).resolve().parent
SCHEDULE_JOB_NAME = "random_media_posting"
MAX_PHOTO_CAPTION = 1024
PLOT_MAX_LENGTH = 260
UNKNOWN_VALUE = "н/д"

SCHEDULE_INTERVALS = [
    (5, "5 мин"),
    (10, "10 мин"),
    (30, "30 мин"),
    (60, "1 час"),
    (120, "2 часа"),
    (180, "3 часа"),
]

API_KEY_LABELS = {
    "groq_api_key": "Groq",
    "gemini_api_key": "Gemini",
    "tmdb_api_key": "TMDb",
    "omdb_api_key": "OMDb",
}

POSTER_SETTING_LABELS = {
    "badge_block_x": "Блок X",
    "badge_block_y": "Блок Y",
    "badge_block_width": "Ширина блока",
    "badge_block_height": "Высота блока",
    "badge_block_opacity": "Прозрачность блока",
    "badge_text_x": "Текст X",
    "badge_text_y": "Текст Y",
    "badge_text_size": "Размер текста",
    "badge_text_color": "Цвет текста",
}

DEFAULT_SETTINGS = {
    "groq_api_key": "",
    "gemini_api_key": "",
    "tmdb_api_key": "",
    "omdb_api_key": "",
    "schedule_enabled": "0",
    "schedule_interval_minutes": "10",
    "badge_block_x": "right",
    "badge_block_y": "24",
    "badge_block_width": "132",
    "badge_block_height": "38",
    "badge_block_opacity": "155",
    "badge_block_radius": "12",
    "badge_text_x": "auto",
    "badge_text_y": "auto",
    "badge_text_size": "22",
    "badge_text_color": "#FFFFFF",
}

OLD_POSTER_DEFAULTS = {
    "badge_block_x": "24",
    "badge_block_y": "24",
    "badge_block_width": "290",
    "badge_block_height": "64",
    "badge_block_opacity": "155",
    "badge_text_x": "42",
    "badge_text_y": "38",
    "badge_text_size": "30",
    "badge_text_color": "#FFFFFF",
}

POSTER_BADGE_V2_DEFAULTS = {
    "badge_block_x": "right",
    "badge_block_y": "24",
    "badge_block_width": "360",
    "badge_block_height": "58",
    "badge_block_opacity": "155",
    "badge_text_x": "auto",
    "badge_text_y": "auto",
    "badge_text_size": "28",
    "badge_text_color": "#FFFFFF",
}

GENRE_TRANSLATIONS = {
    "action": "боевик",
    "adventure": "приключения",
    "animation": "мультфильм",
    "biography": "биография",
    "comedy": "комедия",
    "crime": "криминал",
    "documentary": "документальный",
    "drama": "драма",
    "family": "семейный",
    "fantasy": "фэнтези",
    "history": "история",
    "horror": "ужасы",
    "music": "музыка",
    "musical": "мюзикл",
    "mystery": "детектив",
    "romance": "мелодрама",
    "sci-fi": "фантастика",
    "science fiction": "фантастика",
    "sport": "спорт",
    "thriller": "триллер",
    "war": "военный",
    "western": "вестерн",
}

RATING_TO_AGE = {
    "G": "0+",
    "PG": "6+",
    "PG-13": "12+",
    "R": "18+",
    "NC-17": "18+",
    "TV-Y": "0+",
    "TV-Y7": "6+",
    "TV-G": "0+",
    "TV-PG": "12+",
    "TV-14": "16+",
    "TV-MA": "18+",
}


class SingleInstanceLock:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.handle: Any = None

    def acquire(self) -> bool:
        self.handle = self.path.open("a+b")
        try:
            if self.path.stat().st_size == 0:
                self.handle.write(b"0")
                self.handle.flush()
        except OSError:
            self.handle.close()
            self.handle = None
            return False

        self.handle.seek(0)
        try:
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.handle.close()
            self.handle = None
            return False

        self.handle.seek(0)
        try:
            self.handle.truncate()
            self.handle.write(str(os.getpid()).encode("ascii"))
            self.handle.flush()
            self.handle.seek(0)
            if self.path.stat().st_size == 0:
                self.handle.write(b"0")
                self.handle.flush()
                self.handle.seek(0)
        except OSError:
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            self.handle.close()
            self.handle = None
            return False
        return True

    def release(self) -> None:
        if not self.handle:
            return
        try:
            self.handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        finally:
            self.handle.close()
            self.handle = None


class MetadataLookupError(RuntimeError):
    pass


@dataclass
class MediaInfo:
    query: str
    title_ru: str
    title_en: str
    age: str
    release_date: str
    media_type: str
    genres: str
    overview: str
    imdb_rating: str
    poster_url: str | None
    imdb_id: str | None


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.RLock()
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection

    @contextmanager
    def _connection(self) -> Any:
        connection = self._connect()
        try:
            yield connection
            connection.commit()
        finally:
            connection.close()

    def _init_schema(self) -> None:
        with self._lock, self._connection() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS admins (
                    user_id INTEGER PRIMARY KEY,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS destinations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id TEXT NOT NULL,
                    message_thread_id INTEGER NOT NULL DEFAULT 0,
                    title TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    added_at TEXT NOT NULL,
                    UNIQUE(chat_id, message_thread_id)
                );

                CREATE TABLE IF NOT EXISTS media_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL UNIQUE COLLATE NOCASE,
                    created_at TEXT NOT NULL,
                    last_posted_at TEXT,
                    posted_count INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS post_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    media_id INTEGER NOT NULL,
                    sent_at TEXT NOT NULL,
                    success_count INTEGER NOT NULL,
                    FOREIGN KEY(media_id) REFERENCES media_items(id)
                );
                """
            )
            self._migrate_destinations_schema(connection)
            for key, value in DEFAULT_SETTINGS.items():
                connection.execute(
                    "INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)",
                    (key, value),
                )
            self._migrate_old_poster_defaults(connection)
            self._migrate_imdb_only_badge_defaults(connection)

    def _migrate_old_poster_defaults(self, connection: sqlite3.Connection) -> None:
        migrated = connection.execute(
            "SELECT value FROM settings WHERE key = ?",
            ("poster_badge_v2_migrated",),
        ).fetchone()
        if migrated and migrated["value"] == "1":
            return

        for key, old_value in OLD_POSTER_DEFAULTS.items():
            row = connection.execute(
                "SELECT value FROM settings WHERE key = ?",
                (key,),
            ).fetchone()
            if row and row["value"] == old_value:
                connection.execute(
                    "UPDATE settings SET value = ? WHERE key = ?",
                    (DEFAULT_SETTINGS[key], key),
                )
        connection.execute(
            """
            INSERT INTO settings(key, value) VALUES(?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value
            """,
            ("poster_badge_v2_migrated", "1"),
        )

    def _migrate_imdb_only_badge_defaults(self, connection: sqlite3.Connection) -> None:
        migrated = connection.execute(
            "SELECT value FROM settings WHERE key = ?",
            ("poster_badge_imdb_only_v3_migrated",),
        ).fetchone()
        if migrated and migrated["value"] == "1":
            return

        for key, old_value in POSTER_BADGE_V2_DEFAULTS.items():
            row = connection.execute(
                "SELECT value FROM settings WHERE key = ?",
                (key,),
            ).fetchone()
            if row and row["value"] == old_value:
                connection.execute(
                    "UPDATE settings SET value = ? WHERE key = ?",
                    (DEFAULT_SETTINGS[key], key),
                )
        connection.execute(
            """
            INSERT INTO settings(key, value) VALUES(?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value
            """,
            ("poster_badge_imdb_only_v3_migrated", "1"),
        )

    def _migrate_destinations_schema(self, connection: sqlite3.Connection) -> None:
        columns = {
            row["name"]
            for row in connection.execute("PRAGMA table_info(destinations)").fetchall()
        }
        if "message_thread_id" in columns:
            return

        rows = connection.execute(
            "SELECT id, chat_id, title, kind, added_at FROM destinations ORDER BY id",
        ).fetchall()
        connection.execute("ALTER TABLE destinations RENAME TO destinations_old")
        connection.execute(
            """
            CREATE TABLE destinations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id TEXT NOT NULL,
                message_thread_id INTEGER NOT NULL DEFAULT 0,
                title TEXT NOT NULL,
                kind TEXT NOT NULL,
                added_at TEXT NOT NULL,
                UNIQUE(chat_id, message_thread_id)
            )
            """
        )
        for row in rows:
            connection.execute(
                """
                INSERT OR IGNORE INTO destinations(
                    id, chat_id, message_thread_id, title, kind, added_at
                )
                VALUES(?, ?, 0, ?, ?, ?)
                """,
                (row["id"], row["chat_id"], row["title"], row["kind"], row["added_at"]),
            )
        connection.execute("DROP TABLE destinations_old")

    def seed_admins(self, admin_ids: list[int]) -> None:
        for user_id in admin_ids:
            self.add_admin(user_id)

    def add_admin(self, user_id: int) -> None:
        with self._lock, self._connection() as connection:
            connection.execute(
                "INSERT OR IGNORE INTO admins(user_id, created_at) VALUES(?, ?)",
                (user_id, utc_now()),
            )

    def has_admins(self) -> bool:
        with self._lock, self._connection() as connection:
            row = connection.execute("SELECT COUNT(*) AS count FROM admins").fetchone()
            return bool(row["count"])

    def is_admin(self, user_id: int) -> bool:
        with self._lock, self._connection() as connection:
            row = connection.execute(
                "SELECT 1 FROM admins WHERE user_id = ?",
                (user_id,),
            ).fetchone()
            return row is not None

    def list_admin_ids(self) -> list[int]:
        with self._lock, self._connection() as connection:
            rows = connection.execute("SELECT user_id FROM admins ORDER BY created_at").fetchall()
            return [int(row["user_id"]) for row in rows]

    def get_setting(self, key: str, default: str = "") -> str:
        with self._lock, self._connection() as connection:
            row = connection.execute(
                "SELECT value FROM settings WHERE key = ?",
                (key,),
            ).fetchone()
            return row["value"] if row else default

    def set_setting(self, key: str, value: str) -> None:
        with self._lock, self._connection() as connection:
            connection.execute(
                """
                INSERT INTO settings(key, value) VALUES(?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """,
                (key, value),
            )

    def get_settings(self) -> dict[str, str]:
        with self._lock, self._connection() as connection:
            rows = connection.execute("SELECT key, value FROM settings").fetchall()
            return {row["key"]: row["value"] for row in rows}

    def add_destination(self, chat_id: str, message_thread_id: int, title: str, kind: str) -> bool:
        with self._lock, self._connection() as connection:
            if message_thread_id:
                existing_thread = connection.execute(
                    """
                    SELECT 1 FROM destinations
                    WHERE chat_id = ? AND message_thread_id = ?
                    """,
                    (chat_id, message_thread_id),
                ).fetchone()
                if existing_thread:
                    return False

                cursor = connection.execute(
                    """
                    UPDATE destinations
                    SET message_thread_id = ?,
                        title = ?,
                        kind = ?,
                        added_at = ?
                    WHERE chat_id = ? AND message_thread_id = 0
                    """,
                    (message_thread_id, title, kind, utc_now(), chat_id),
                )
                if cursor.rowcount:
                    return True

            cursor = connection.execute(
                """
                INSERT OR IGNORE INTO destinations(
                    chat_id, message_thread_id, title, kind, added_at
                )
                VALUES(?, ?, ?, ?, ?)
                """,
                (chat_id, message_thread_id, title, kind, utc_now()),
            )
            return cursor.rowcount > 0

    def delete_destination(self, destination_id: int) -> bool:
        with self._lock, self._connection() as connection:
            cursor = connection.execute(
                "DELETE FROM destinations WHERE id = ?",
                (destination_id,),
            )
            return cursor.rowcount > 0

    def list_destinations(self) -> list[sqlite3.Row]:
        with self._lock, self._connection() as connection:
            return connection.execute(
                "SELECT * FROM destinations ORDER BY id DESC",
            ).fetchall()

    def add_media_titles(self, titles: list[str]) -> tuple[int, int]:
        added = 0
        skipped = 0
        with self._lock, self._connection() as connection:
            for title in titles:
                cursor = connection.execute(
                    "INSERT OR IGNORE INTO media_items(title, created_at) VALUES(?, ?)",
                    (title, utc_now()),
                )
                if cursor.rowcount:
                    added += 1
                else:
                    skipped += 1
        return added, skipped

    def get_random_unposted_media(self) -> sqlite3.Row | None:
        with self._lock, self._connection() as connection:
            return connection.execute(
                """
                SELECT * FROM media_items
                WHERE posted_count = 0
                ORDER BY RANDOM()
                LIMIT 1
                """
            ).fetchone()

    def mark_media_posted(self, media_id: int, success_count: int) -> None:
        with self._lock, self._connection() as connection:
            now = utc_now()
            connection.execute(
                """
                UPDATE media_items
                SET posted_count = posted_count + 1,
                    last_posted_at = ?
                WHERE id = ?
                """,
                (now, media_id),
            )
            connection.execute(
                """
                INSERT INTO post_history(media_id, sent_at, success_count)
                VALUES(?, ?, ?)
                """,
                (media_id, now, success_count),
            )

    def mark_media_failed(self, media_id: int) -> None:
        with self._lock, self._connection() as connection:
            connection.execute(
                """
                UPDATE media_items
                SET posted_count = -1,
                    last_posted_at = ?
                WHERE id = ?
                """,
                (utc_now(), media_id),
            )

    def reset_history(self) -> None:
        with self._lock, self._connection() as connection:
            connection.execute(
                "UPDATE media_items SET posted_count = 0, last_posted_at = NULL",
            )
            connection.execute("DELETE FROM post_history")

    def stats(self) -> dict[str, int]:
        with self._lock, self._connection() as connection:
            total = connection.execute(
                "SELECT COUNT(*) AS count FROM media_items",
            ).fetchone()["count"]
            posted = connection.execute(
                "SELECT COUNT(*) AS count FROM media_items WHERE posted_count > 0",
            ).fetchone()["count"]
            failed = connection.execute(
                "SELECT COUNT(*) AS count FROM media_items WHERE posted_count < 0",
            ).fetchone()["count"]
            destinations = connection.execute(
                "SELECT COUNT(*) AS count FROM destinations",
            ).fetchone()["count"]
            return {
                "total": total,
                "posted": posted,
                "failed": failed,
                "remaining": total - posted - failed,
                "destinations": destinations,
            }


class MetadataClient:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def resolve(self, query: str) -> MediaInfo:
        settings = self.db.get_settings()
        tmdb_data = await self._fetch_tmdb(query, settings.get("tmdb_api_key", ""))
        omdb_data = await self._fetch_omdb(query, settings.get("omdb_api_key", ""), tmdb_data)

        imdb_id = tmdb_data.get("imdb_id") or pick_omdb(omdb_data, "imdbID")
        raw_imdb_rating = pick_omdb(omdb_data, "imdbRating")
        if not imdb_id or not is_valid_imdb_rating(raw_imdb_rating):
            raise MetadataLookupError(f"IMDb не нашел данные или оценку для: {query}")

        title_ru = tmdb_data.get("title_ru") or pick_omdb(omdb_data, "Title") or query
        title_en = choose_english_title(
            [
                tmdb_data.get("title_en"),
                pick_omdb(omdb_data, "Title"),
                tmdb_data.get("original_title"),
                query,
            ],
            fallback=title_ru,
        )
        age = tmdb_data.get("age") or normalize_age(pick_omdb(omdb_data, "Rated")) or UNKNOWN_VALUE
        release_date = (
            format_iso_date(tmdb_data.get("release_date"))
            or format_omdb_date(pick_omdb(omdb_data, "Released"))
            or UNKNOWN_VALUE
        )
        media_type = detect_media_type(tmdb_data, omdb_data)
        genres = translate_omdb_genres(pick_omdb(omdb_data, "Genre")) or tmdb_data.get("genres") or UNKNOWN_VALUE
        overview = shorten_plot(tmdb_data.get("overview") or pick_omdb(omdb_data, "Plot") or "")
        poster_url = tmdb_data.get("poster_url") or pick_omdb(omdb_data, "Poster")
        imdb_rating = raw_imdb_rating or UNKNOWN_VALUE

        if imdb_rating not in {UNKNOWN_VALUE, "N/A"}:
            imdb_rating = f"{imdb_rating}/10" if "/" not in imdb_rating else imdb_rating
        else:
            imdb_rating = UNKNOWN_VALUE

        missing_fields = []
        if not is_likely_english_title(title_en):
            missing_fields.append("английское название")
        if release_date == UNKNOWN_VALUE:
            missing_fields.append("дата выхода")
        if genres == UNKNOWN_VALUE:
            missing_fields.append("жанр")
        if not overview:
            missing_fields.append("сюжет")
        if not poster_url or poster_url == "N/A":
            missing_fields.append("постер")
        if missing_fields:
            raise MetadataLookupError(
                f"Недостаточно данных для {query}: {', '.join(missing_fields)}"
            )

        return MediaInfo(
            query=query,
            title_ru=title_ru,
            title_en=title_en,
            age=age,
            release_date=release_date,
            media_type=media_type,
            genres=genres,
            overview=overview,
            imdb_rating=imdb_rating,
            poster_url=poster_url,
            imdb_id=imdb_id,
        )

    async def _fetch_tmdb(self, query: str, api_key: str) -> dict[str, Any]:
        if not api_key:
            return {}

        headers = {"accept": "application/json"}
        params = {
            "api_key": api_key,
            "query": query,
            "language": "ru-RU",
            "include_adult": "false",
        }

        async with httpx.AsyncClient(timeout=20) as client:
            search_response = await client.get(
                "https://api.themoviedb.org/3/search/multi",
                params=params,
                headers=headers,
            )
            search_response.raise_for_status()
            results = [
                item
                for item in search_response.json().get("results", [])
                if item.get("media_type") in {"movie", "tv"}
            ]
            if not results:
                return {}

            item = results[0]
            media_type = item["media_type"]
            item_id = item["id"]
            append = "external_ids,release_dates" if media_type == "movie" else "external_ids,content_ratings"
            detail_response = await client.get(
                f"https://api.themoviedb.org/3/{media_type}/{item_id}",
                params={
                    "api_key": api_key,
                    "language": "ru-RU",
                    "append_to_response": append,
                },
                headers=headers,
            )
            detail_response.raise_for_status()
            detail = detail_response.json()
            detail_en_response = await client.get(
                f"https://api.themoviedb.org/3/{media_type}/{item_id}",
                params={
                    "api_key": api_key,
                    "language": "en-US",
                },
                headers=headers,
            )
            detail_en_response.raise_for_status()
            detail_en = detail_en_response.json()

        title_ru = detail.get("title") or detail.get("name") or item.get("title") or item.get("name")
        title_en = (
            detail_en.get("title")
            or detail_en.get("name")
            or detail.get("original_title")
            or detail.get("original_name")
            or item.get("original_title")
            or item.get("original_name")
        )
        release_date = detail.get("release_date") or detail.get("first_air_date")
        poster_path = detail.get("poster_path") or item.get("poster_path")
        genres = ", ".join(
            str(genre.get("name", "")).strip().lower()
            for genre in detail.get("genres", [])
            if genre.get("name")
        )
        vote_average = detail.get("vote_average")

        return {
            "tmdb_media_type": media_type,
            "title_ru": title_ru,
            "title_en": title_en,
            "original_title": title_en,
            "release_date": release_date,
            "genres": genres,
            "overview": detail.get("overview") or item.get("overview") or "",
            "poster_url": f"https://image.tmdb.org/t/p/w780{poster_path}" if poster_path else None,
            "imdb_id": get_tmdb_imdb_id(detail, media_type),
            "age": get_tmdb_age(detail, media_type),
            "original_language": detail.get("original_language") or item.get("original_language"),
            "vote_average": f"{float(vote_average):.1f}" if isinstance(vote_average, (int, float)) else "",
        }

    async def _fetch_omdb(
        self,
        query: str,
        api_key: str,
        tmdb_data: dict[str, Any],
    ) -> dict[str, Any]:
        if not api_key:
            return {}

        async with httpx.AsyncClient(timeout=20) as client:
            if tmdb_data.get("imdb_id"):
                data = await fetch_omdb_json(
                    client,
                    {"apikey": api_key, "plot": "short", "r": "json", "i": tmdb_data["imdb_id"]},
                )
                if data:
                    return data

            for title in dedupe_preserve_order(
                [
                    title
                    for title in [
                        tmdb_data.get("title_en"),
                        tmdb_data.get("original_title"),
                        tmdb_data.get("title_ru"),
                        query,
                    ]
                    if title
                ]
            ):
                data = await fetch_omdb_json(
                    client,
                    {"apikey": api_key, "plot": "short", "r": "json", "t": title},
                )
                if data:
                    return data

        return {}


async def fetch_omdb_json(client: httpx.AsyncClient, params: dict[str, str]) -> dict[str, Any]:
    response = await client.get("https://www.omdbapi.com/", params=params)
    response.raise_for_status()
    data = response.json()
    if data.get("Response") == "False":
        return {}
    return data


class PosterService:
    def __init__(self, db: Database) -> None:
        self.db = db

    async def build(self, info: MediaInfo) -> io.BytesIO | None:
        if not info.poster_url or info.poster_url == "N/A":
            return None

        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.get(info.poster_url)
            response.raise_for_status()
            image_bytes = response.content

        image = Image.open(io.BytesIO(image_bytes)).convert("RGBA")
        settings = self.db.get_settings()
        draw = ImageDraw.Draw(image, "RGBA")

        badge_text = build_poster_badge_text(info)
        text_size = clamp(as_int(settings.get("badge_text_size"), 30), 10, 140)
        text_color = normalize_hex_color(settings.get("badge_text_color", "#FFFFFF"))
        font = load_font(text_size)
        text_width, text_height, _ = measure_text(draw, badge_text, font)
        horizontal_padding = max(18, text_size)
        vertical_padding = max(8, text_size // 3)

        configured_width = as_int(settings.get("badge_block_width"), 132)
        configured_height = as_int(settings.get("badge_block_height"), 38)
        block_width = clamp(max(configured_width, text_width + horizontal_padding * 2), 72, image.width)
        block_height = clamp(max(configured_height, text_height + vertical_padding * 2), 28, image.height)
        block_x = resolve_badge_block_x(settings.get("badge_block_x"), image.width, block_width)
        block_y = clamp(as_int(settings.get("badge_block_y"), 24), 0, max(0, image.height - block_height))
        opacity = clamp(as_int(settings.get("badge_block_opacity"), 155), 0, 255)
        radius = clamp(as_int(settings.get("badge_block_radius"), 12), 0, 80)

        draw.rounded_rectangle(
            (block_x, block_y, block_x + block_width, block_y + block_height),
            radius=radius,
            fill=(0, 0, 0, opacity),
        )

        text_x, text_y = resolve_badge_text_position(
            draw=draw,
            text=badge_text,
            font=font,
            settings=settings,
            block_x=block_x,
            block_y=block_y,
            block_width=block_width,
            block_height=block_height,
        )

        draw.text(
            (text_x, text_y),
            badge_text,
            fill=text_color,
            font=font,
            stroke_width=2,
            stroke_fill=(0, 0, 0, 180),
        )

        output = io.BytesIO()
        image.convert("RGB").save(output, format="JPEG", quality=92)
        output.seek(0)
        return output


class MovieBot:
    def __init__(self, db: Database) -> None:
        self.db = db
        self.metadata = MetadataClient(db)
        self.poster = PosterService(db)

    def register(self, application: Application) -> None:
        application.add_handler(CommandHandler("start", self.start))
        application.add_handler(CommandHandler("menu", self.menu))
        application.add_handler(CommandHandler("post", self.post_now_command))
        application.add_handler(CallbackQueryHandler(self.callback))
        application.add_handler(MessageHandler(filters.Document.ALL, self.document_message))
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.text_message))
        application.add_error_handler(self.error_handler)

    async def error_handler(self, update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
        if isinstance(context.error, Conflict):
            logging.error(
                "Telegram 409 Conflict: этот бот уже запущен в другом процессе, "
                "терминале, хостинге или сервисе. Остановите второй экземпляр."
            )
            context.application.stop_running()
            return
        if context.error:
            logging.error(
                "Unhandled bot error",
                exc_info=(type(context.error), context.error, context.error.__traceback__),
            )
        else:
            logging.error("Unhandled bot error")

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.ensure_admin(update):
            return
        await update.effective_message.reply_text(
            "Бот готов. Выберите действие:",
            reply_markup=main_menu(),
        )

    async def menu(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.ensure_admin(update):
            return
        await update.effective_message.reply_text("Главное меню:", reply_markup=main_menu())

    async def post_now_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.ensure_admin(update):
            return
        result = await self.publish_random(context.application, manual_chat_id=update.effective_chat.id)
        await update.effective_message.reply_text(result)

    async def ensure_admin(self, update: Update) -> bool:
        user = update.effective_user
        chat = update.effective_chat
        if not user or not chat:
            return False
        if chat.type != "private":
            return False
        if not self.db.has_admins():
            self.db.add_admin(user.id)
            await update.effective_message.reply_text(
                "Вы назначены администратором, потому что список администраторов был пуст.",
            )
            return True
        if self.db.is_admin(user.id):
            return True
        await update.effective_message.reply_text("Нет доступа.")
        return False

    async def callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.ensure_admin(update):
            return

        query = update.callback_query
        if not query:
            return
        await query.answer()
        data = query.data or ""

        if data == "menu:main":
            await query.edit_message_text("Главное меню:", reply_markup=main_menu())
        elif data == "media:add":
            context.user_data["state"] = {"name": "awaiting_media_list"}
            await query.edit_message_text(
                "Отправьте список названий в столбик текстом или файлом `.txt`, `.csv`, `.xlsx`.",
                reply_markup=back_menu(),
            )
        elif data == "post:now":
            await query.edit_message_text("Ищу случайный неповторяющийся тайтл и готовлю пост...")
            result = await self.publish_random(context.application, manual_chat_id=query.message.chat_id)
            await query.message.reply_text(result, reply_markup=main_menu())
        elif data == "stats":
            await query.edit_message_text(self.render_stats(), reply_markup=stats_menu())
        elif data == "history:reset":
            self.db.reset_history()
            await query.edit_message_text("История публикаций сброшена. Все тайтлы снова доступны.", reply_markup=main_menu())
        elif data == "api:menu":
            await query.edit_message_text(self.render_api_settings(), reply_markup=api_menu(self.db))
        elif data.startswith("api:set:"):
            key = data.split(":", 2)[2]
            context.user_data["state"] = {"name": "awaiting_api_key", "key": key}
            await query.edit_message_text(
                f"Отправьте API ключ для {API_KEY_LABELS[key]}.\nЧтобы очистить ключ, отправьте `-`.",
                reply_markup=back_menu("api:menu"),
                parse_mode=ParseMode.MARKDOWN,
            )
        elif data == "dest:menu":
            await query.edit_message_text(self.render_destinations(), reply_markup=destinations_menu(self.db))
        elif data == "dest:add":
            context.user_data["state"] = {"name": "awaiting_destination"}
            prompt = (
                "Вставьте ссылку на канал, группу или тему одним сообщением.\n\n"
                "Форматы:\n"
                "@sqt2low\n"
                "https://t.me/sqt2lowss\n"
                "https://t.me/c/3988076227/305\n"
                "-1003988076227\n\n"
                "Если нужна конкретная тема в группе, отправьте ссылку именно на эту тему, "
                "например https://t.me/c/3988076227/305."
            )
            try:
                await query.edit_message_text(prompt, reply_markup=back_menu("dest:menu"))
            except TelegramError:
                await query.message.reply_text(prompt, reply_markup=back_menu("dest:menu"))
        elif data.startswith("dest:delete:"):
            destination_id = int(data.rsplit(":", 1)[1])
            deleted = self.db.delete_destination(destination_id)
            text = "Канал/группа удалены." if deleted else "Запись не найдена."
            await query.edit_message_text(text + "\n\n" + self.render_destinations(), reply_markup=destinations_menu(self.db))
        elif data == "schedule:menu":
            await query.edit_message_text(self.render_schedule(), reply_markup=schedule_menu(self.db))
        elif data == "schedule:toggle":
            enabled = self.db.get_setting("schedule_enabled") == "1"
            self.db.set_setting("schedule_enabled", "0" if enabled else "1")
            configure_schedule_job(context.application, self)
            await query.edit_message_text(self.render_schedule(), reply_markup=schedule_menu(self.db))
        elif data.startswith("schedule:set:"):
            minutes = data.rsplit(":", 1)[1]
            self.db.set_setting("schedule_interval_minutes", minutes)
            self.db.set_setting("schedule_enabled", "1")
            configure_schedule_job(context.application, self)
            await query.edit_message_text(self.render_schedule(), reply_markup=schedule_menu(self.db))
        elif data == "poster:menu":
            await query.edit_message_text(self.render_poster_settings(), reply_markup=poster_menu())
        elif data.startswith("poster:set:"):
            key = data.split(":", 2)[2]
            context.user_data["state"] = {"name": "awaiting_poster_value", "key": key}
            await query.edit_message_text(
                poster_value_prompt(key),
                reply_markup=back_menu("poster:menu"),
            )

    async def text_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.ensure_admin(update):
            return

        state = context.user_data.get("state") or {}
        text = update.effective_message.text or ""

        if state.get("name") == "awaiting_api_key":
            key = state["key"]
            self.db.set_setting(key, "" if text.strip() == "-" else text.strip())
            context.user_data.pop("state", None)
            await update.effective_message.reply_text(
                f"{API_KEY_LABELS[key]} сохранен.",
                reply_markup=api_menu(self.db),
            )
        elif state.get("name") == "awaiting_destination":
            try:
                chat_id, message_thread_id, kind, title = parse_destination(text)
            except ValueError as error:
                await update.effective_message.reply_text(str(error), reply_markup=back_menu("dest:menu"))
                return
            added = self.db.add_destination(chat_id, message_thread_id, title, kind)
            context.user_data.pop("state", None)
            result = "Добавлено." if added else "Такая группа/канал уже есть."
            await update.effective_message.reply_text(result, reply_markup=destinations_menu(self.db))
        elif state.get("name") == "awaiting_media_list":
            titles = parse_titles_from_text(text)
            await self.save_titles(update, context, titles)
        elif state.get("name") == "awaiting_poster_value":
            key = state["key"]
            value = text.strip()
            error = validate_poster_value(key, value)
            if error:
                await update.effective_message.reply_text(error, reply_markup=back_menu("poster:menu"))
                return
            self.db.set_setting(key, value)
            context.user_data.pop("state", None)
            await update.effective_message.reply_text("Настройка постера сохранена.", reply_markup=poster_menu())
        else:
            await update.effective_message.reply_text("Откройте меню и выберите действие.", reply_markup=main_menu())

    async def document_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self.ensure_admin(update):
            return

        state = context.user_data.get("state") or {}
        if state.get("name") != "awaiting_media_list":
            await update.effective_message.reply_text(
                "Файл принят только в режиме добавления списка. Нажмите «Добавить список».",
                reply_markup=main_menu(),
            )
            return

        document = update.effective_message.document
        if not document:
            return
        telegram_file = await document.get_file()
        file_bytes = await telegram_file.download_as_bytearray()

        try:
            titles = parse_titles_from_file(document.file_name or "", bytes(file_bytes))
        except ValueError as error:
            await update.effective_message.reply_text(str(error), reply_markup=back_menu())
            return
        await self.save_titles(update, context, titles)

    async def save_titles(
        self,
        update: Update,
        context: ContextTypes.DEFAULT_TYPE,
        titles: list[str],
    ) -> None:
        if not titles:
            await update.effective_message.reply_text("Не нашел названия в списке.", reply_markup=back_menu())
            return
        added, skipped = self.db.add_media_titles(titles)
        context.user_data.pop("state", None)
        await update.effective_message.reply_text(
            f"Список сохранен.\nДобавлено: {added}\nПропущено дублей: {skipped}",
            reply_markup=main_menu(),
        )

    async def publish_random(self, application: Application, manual_chat_id: int | None = None) -> str:
        stats = self.db.stats()
        destinations = self.db.list_destinations()
        if not destinations:
            return "Сначала добавьте канал или группу для публикации."
        if stats["remaining"] <= 0:
            return "Неповторяющиеся тайтлы закончились. Можно загрузить новый список или сбросить историю."

        media_row = self.db.get_random_unposted_media()
        if not media_row:
            return "Нет доступных тайтлов для публикации."

        try:
            info = await self.metadata.resolve(media_row["title"])
        except MetadataLookupError as error:
            self.db.mark_media_failed(media_row["id"])
            message = f"Ошибка: не удалось отправить «{media_row['title']}». {error}"
            logging.warning(message)
            await self.notify_admins(application, message, manual_chat_id)
            return message
        except Exception as error:
            logging.exception("Metadata lookup failed for %s", media_row["title"])
            message = (
                f"Ошибка: не удалось отправить «{media_row['title']}». "
                f"Не получилось получить данные фильма: {error}"
            )
            await self.notify_admins(application, message, manual_chat_id)
            return message

        caption = build_caption(info)
        poster_file = None
        try:
            poster_file = await self.poster.build(info)
        except Exception as error:
            logging.exception("Poster build failed for %s", media_row["title"])
            message = (
                f"Ошибка: не удалось отправить «{media_row['title']}». "
                f"Не получилось подготовить постер: {error}"
            )
            await self.notify_admins(application, message, manual_chat_id)
            return message
        if poster_file is None:
            message = f"Ошибка: не удалось отправить «{media_row['title']}». Постер не найден."
            await self.notify_admins(application, message, manual_chat_id)
            return message

        success_count = 0
        failures = []
        for destination in destinations:
            try:
                await send_post(
                    application,
                    destination["chat_id"],
                    destination["message_thread_id"],
                    caption,
                    poster_file,
                )
                success_count += 1
                if poster_file:
                    poster_file.seek(0)
            except TelegramError as error:
                failures.append(f"{destination['title']}: {error.message}")
                logging.exception("Telegram send failed")

        if success_count:
            self.db.mark_media_posted(media_row["id"], success_count)

        if manual_chat_id and failures:
            await application.bot.send_message(
                chat_id=manual_chat_id,
                text="Не удалось отправить в некоторые места:\n" + "\n".join(failures[:5]),
            )

        if not success_count:
            return "Пост не отправлен ни в один канал/группу. Проверьте права бота."
        return f"Опубликовано: {info.title_ru}.\nУспешных отправок: {success_count}"

    async def notify_admins(
        self,
        application: Application,
        message: str,
        manual_chat_id: int | None = None,
    ) -> None:
        if manual_chat_id:
            return
        targets = [manual_chat_id] if manual_chat_id else self.db.list_admin_ids()
        for chat_id in dict.fromkeys(target for target in targets if target):
            try:
                await application.bot.send_message(chat_id=chat_id, text=message)
            except TelegramError:
                logging.exception("Failed to notify admin %s", chat_id)

    def render_api_settings(self) -> str:
        settings = self.db.get_settings()
        lines = ["API ключи:"]
        for key, label in API_KEY_LABELS.items():
            status = "задан" if settings.get(key) else "не задан"
            lines.append(f"{label}: {status}")
        return "\n".join(lines)

    def render_destinations(self) -> str:
        destinations = self.db.list_destinations()
        if not destinations:
            return "Каналы и группы не добавлены."
        lines = ["Каналы и группы:"]
        for destination in destinations:
            topic = (
                f", тема {destination['message_thread_id']}"
                if destination["message_thread_id"]
                else ""
            )
            lines.append(f"{destination['id']}. {destination['title']} ({destination['chat_id']}{topic})")
        return "\n".join(lines)

    def render_schedule(self) -> str:
        enabled = self.db.get_setting("schedule_enabled") == "1"
        interval = self.db.get_setting("schedule_interval_minutes", "10")
        status = "включено" if enabled else "выключено"
        return f"Расписание: {status}\nИнтервал: {format_minutes(interval)}"

    def render_poster_settings(self) -> str:
        settings = self.db.get_settings()
        lines = ["Настройки постера:"]
        for key, label in POSTER_SETTING_LABELS.items():
            lines.append(f"{label}: {settings.get(key, DEFAULT_SETTINGS[key])}")
        return "\n".join(lines)

    def render_stats(self) -> str:
        stats = self.db.stats()
        return (
            "Статистика:\n"
            f"Всего в списке: {stats['total']}\n"
            f"Опубликовано: {stats['posted']}\n"
            f"Ошибки поиска: {stats['failed']}\n"
            f"Осталось без повторов: {stats['remaining']}\n"
            f"Каналов/групп: {stats['destinations']}"
        )


def configure_schedule_job(application: Application, bot: MovieBot) -> None:
    for job in application.job_queue.get_jobs_by_name(SCHEDULE_JOB_NAME):
        job.schedule_removal()

    if bot.db.get_setting("schedule_enabled") != "1":
        return

    minutes = as_int(bot.db.get_setting("schedule_interval_minutes"), 10)
    interval_seconds = max(minutes, 1) * 60
    application.job_queue.run_repeating(
        scheduled_post,
        interval=interval_seconds,
        first=interval_seconds,
        name=SCHEDULE_JOB_NAME,
        data=bot,
        job_kwargs={"coalesce": True, "max_instances": 1, "misfire_grace_time": 60},
    )


async def scheduled_post(context: ContextTypes.DEFAULT_TYPE) -> None:
    bot: MovieBot = context.job.data
    result = await bot.publish_random(context.application)
    logging.info("Scheduled post result: %s", result)


async def send_post(
    application: Application,
    chat_id: str,
    message_thread_id: int,
    caption: str,
    poster_file: io.BytesIO | None,
) -> None:
    target = chat_id_for_api(chat_id)
    thread_kwargs = {"message_thread_id": message_thread_id} if message_thread_id else {}
    if poster_file:
        poster_file.seek(0)
        await application.bot.send_photo(
            chat_id=target,
            photo=InputFile(poster_file, filename="poster.jpg"),
            caption=caption,
            parse_mode=ParseMode.HTML,
            **thread_kwargs,
        )
    else:
        await application.bot.send_message(
            chat_id=target,
            text=caption,
            parse_mode=ParseMode.HTML,
            disable_web_page_preview=False,
            **thread_kwargs,
        )


def main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("Добавить список", callback_data="media:add")],
            [InlineKeyboardButton("Отправить сейчас", callback_data="post:now")],
            [
                InlineKeyboardButton("Расписание", callback_data="schedule:menu"),
                InlineKeyboardButton("Каналы/группы", callback_data="dest:menu"),
            ],
            [
                InlineKeyboardButton("API ключи", callback_data="api:menu"),
                InlineKeyboardButton("Постеры", callback_data="poster:menu"),
            ],
            [InlineKeyboardButton("Статистика", callback_data="stats")],
        ]
    )


def api_menu(db: Database) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(f"{label}", callback_data=f"api:set:{key}")]
        for key, label in API_KEY_LABELS.items()
    ]
    rows.append([InlineKeyboardButton("Назад", callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def destinations_menu(db: Database) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton("Добавить", callback_data="dest:add")]]
    for destination in db.list_destinations()[:20]:
        title = destination["title"]
        if destination["message_thread_id"]:
            title = f"{title} · {destination['message_thread_id']}"
        label = f"Удалить {title[:28]}"
        rows.append([InlineKeyboardButton(label, callback_data=f"dest:delete:{destination['id']}")])
    rows.append([InlineKeyboardButton("Назад", callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def schedule_menu(db: Database) -> InlineKeyboardMarkup:
    enabled = db.get_setting("schedule_enabled") == "1"
    rows = [
        [InlineKeyboardButton("Выключить" if enabled else "Включить", callback_data="schedule:toggle")],
    ]
    rows.extend(
        [
            InlineKeyboardButton(label, callback_data=f"schedule:set:{minutes}")
            for minutes, label in SCHEDULE_INTERVALS[index : index + 2]
        ]
        for index in range(0, len(SCHEDULE_INTERVALS), 2)
    )
    rows.append([InlineKeyboardButton("Назад", callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def poster_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [
                InlineKeyboardButton("Блок X", callback_data="poster:set:badge_block_x"),
                InlineKeyboardButton("Блок Y", callback_data="poster:set:badge_block_y"),
            ],
            [
                InlineKeyboardButton("Ширина", callback_data="poster:set:badge_block_width"),
                InlineKeyboardButton("Высота", callback_data="poster:set:badge_block_height"),
            ],
            [InlineKeyboardButton("Прозрачность", callback_data="poster:set:badge_block_opacity")],
            [
                InlineKeyboardButton("Текст X", callback_data="poster:set:badge_text_x"),
                InlineKeyboardButton("Текст Y", callback_data="poster:set:badge_text_y"),
            ],
            [
                InlineKeyboardButton("Размер текста", callback_data="poster:set:badge_text_size"),
                InlineKeyboardButton("Цвет текста", callback_data="poster:set:badge_text_color"),
            ],
            [InlineKeyboardButton("Назад", callback_data="menu:main")],
        ]
    )


def stats_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [
            [InlineKeyboardButton("Сбросить историю публикаций", callback_data="history:reset")],
            [InlineKeyboardButton("Назад", callback_data="menu:main")],
        ]
    )


def back_menu(target: str = "menu:main") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[InlineKeyboardButton("Назад", callback_data=target)]])


def parse_titles_from_text(text: str) -> list[str]:
    titles = []
    for raw_line in text.replace("\ufeff", "").splitlines():
        title = clean_title(raw_line)
        if title:
            titles.append(title)
    return dedupe_preserve_order(titles)


def parse_titles_from_file(file_name: str, data: bytes) -> list[str]:
    lower_name = file_name.lower()
    if lower_name.endswith(".xlsx"):
        workbook = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        sheet = workbook.active
        titles = []
        for row in sheet.iter_rows(min_row=1, max_col=1):
            value = row[0].value
            title = clean_title(str(value)) if value is not None else ""
            if title:
                titles.append(title)
        return dedupe_preserve_order(titles)

    if lower_name.endswith((".txt", ".csv")):
        try:
            text = data.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = data.decode("cp1251", errors="ignore")
        return parse_titles_from_text(text)

    raise ValueError("Поддерживаются файлы `.txt`, `.csv`, `.xlsx`.")


def clean_title(raw: str) -> str:
    title = raw.strip()
    if not title:
        return ""
    if ";" in title:
        title = title.split(";", 1)[0].strip()
    elif "," in title:
        title = title.split(",", 1)[0].strip()
    return re.sub(r"\s+", " ", title)


def dedupe_preserve_order(values: list[str]) -> list[str]:
    seen = set()
    result = []
    for value in values:
        key = value.casefold()
        if key not in seen:
            seen.add(key)
            result.append(value)
    return result


def parse_destination(raw: str) -> tuple[str, int, str, str]:
    value = raw.strip()
    if not value:
        raise ValueError("Пустое значение.")

    c_link = re.search(r"(?:https?://)?t\.me/c/(\d+)(?:/(\d+))?", value)
    if c_link:
        chat_id = f"-100{c_link.group(1)}"
        message_thread_id = int(c_link.group(2) or 0)
        if message_thread_id:
            return chat_id, message_thread_id, "topic", f"Группа {chat_id}, тема {message_thread_id}"
        return chat_id, 0, "group", f"Группа {chat_id}"

    public_link = re.search(r"(?:https?://)?t\.me/([A-Za-z0-9_]{5,})(?:/(\d+))?", value)
    if public_link:
        username = f"@{public_link.group(1)}"
        message_thread_id = int(public_link.group(2) or 0)
        if message_thread_id:
            return username, message_thread_id, "topic", f"{username}, тема {message_thread_id}"
        return username, 0, "public", username

    if re.fullmatch(r"@[A-Za-z0-9_]{5,}", value):
        return value, 0, "public", value

    if re.fullmatch(r"-?\d{5,}", value):
        return value, 0, "chat", value

    raise ValueError("Не понял адрес. Используйте `@name`, ссылку t.me или числовой chat_id.")


def chat_id_for_api(chat_id: str) -> int | str:
    return int(chat_id) if re.fullmatch(r"-?\d+", chat_id) else chat_id


def build_caption(info: MediaInfo) -> str:
    plot = shorten_plot(info.overview) or "Описание не найдено."

    def render(plot_text: str) -> str:
        age_part = f" ({html.escape(info.age)})" if info.age and info.age != UNKNOWN_VALUE else ""
        title = f"🎬 {html.escape(info.title_ru)} / {html.escape(info.title_en)}{age_part}"
        return (
            f"<b>{title}</b>\n\n"
            f"<b>Дата выхода:</b> {html.escape(info.release_date)}\n"
            f"<b>Тип:</b> {html.escape(info.media_type)}\n"
            f"<b>Жанр:</b> {html.escape(info.genres)}\n\n"
            f"<b>Сюжет:</b> {html.escape(plot_text)}\n\n"
            f"<b>Оценка IMDb:</b> {html.escape(info.imdb_rating)}"
        )

    caption = render(plot)
    while len(caption) > MAX_PHOTO_CAPTION and len(plot) > 120:
        plot = plot[: max(120, len(plot) - 120)].rstrip(" .,;:") + "..."
        caption = render(plot)
    return caption


def build_poster_badge_text(info: MediaInfo) -> str:
    return f"IMDb {poster_rating_value(info.imdb_rating)}"


def poster_rating_value(value: str) -> str:
    match = re.search(r"\d+(?:\.\d+)?", value or "")
    return match.group(0) if match else UNKNOWN_VALUE


def is_valid_imdb_rating(value: str | None) -> bool:
    if not value or value == "N/A":
        return False
    return bool(re.fullmatch(r"\d+(?:\.\d+)?", value.strip()))


def choose_english_title(values: list[str | None], fallback: str) -> str:
    for value in values:
        if value and is_likely_english_title(value) and value.casefold() != fallback.casefold():
            return value.strip()
    for value in values:
        if value and is_likely_english_title(value):
            return value.strip()
    return fallback


def is_likely_english_title(value: str) -> bool:
    text = value.strip()
    if not text:
        return False
    if re.search(r"[А-Яа-яЁё]", text):
        return False
    return bool(re.search(r"[A-Za-z]", text))


def shorten_plot(value: str, limit: int = PLOT_MAX_LENGTH) -> str:
    text = re.sub(r"\s+", " ", (value or "").strip())
    if not text or text == "N/A":
        return ""
    if len(text) <= limit:
        return text

    cut = text[:limit]
    sentence_end = max(cut.rfind("."), cut.rfind("!"), cut.rfind("?"))
    if sentence_end >= 120:
        return cut[: sentence_end + 1].strip()

    ellipsis = "..."
    cut = text[: max(1, limit - len(ellipsis))]
    word_end = cut.rfind(" ")
    if word_end >= 120:
        cut = cut[:word_end]
    return cut.rstrip(" .,;:") + ellipsis


def resolve_badge_block_x(value: str | None, image_width: int, block_width: int) -> int:
    margin = 24
    if not is_integer_string(value):
        return max(0, image_width - block_width - margin)
    return clamp(as_int(value, image_width - block_width - margin), 0, max(0, image_width - block_width))


def resolve_badge_text_position(
    draw: ImageDraw.ImageDraw,
    text: str,
    font: ImageFont.ImageFont,
    settings: dict[str, str],
    block_x: int,
    block_y: int,
    block_width: int,
    block_height: int,
) -> tuple[int, int]:
    text_width, text_height, text_top = measure_text(draw, text, font)
    text_x_setting = settings.get("badge_text_x")
    text_y_setting = settings.get("badge_text_y")

    if is_integer_string(text_x_setting):
        text_x = as_int(text_x_setting, block_x + 18)
    else:
        text_x = block_x + block_width - text_width - 18

    if is_integer_string(text_y_setting):
        text_y = as_int(text_y_setting, block_y + 12)
    else:
        text_y = block_y + (block_height - text_height) // 2 - text_top

    return text_x, text_y


def fit_font_to_width(
    draw: ImageDraw.ImageDraw,
    text: str,
    target_size: int,
    max_width: int,
) -> ImageFont.ImageFont:
    for size in range(target_size, 9, -1):
        font = load_font(size)
        text_width, _, _ = measure_text(draw, text, font)
        if text_width <= max_width:
            return font
    return load_font(10)


def measure_text(
    draw: ImageDraw.ImageDraw,
    text: str,
    font: ImageFont.ImageFont,
) -> tuple[int, int, int]:
    left, top, right, bottom = draw.textbbox((0, 0), text, font=font)
    return right - left, bottom - top, top


def is_integer_string(value: str | None) -> bool:
    return bool(re.fullmatch(r"-?\d+", str(value or "").strip()))


def detect_media_type(tmdb_data: dict[str, Any], omdb_data: dict[str, Any]) -> str:
    genres = f"{tmdb_data.get('genres', '')} {pick_omdb(omdb_data, 'Genre') or ''}".lower()
    original_language = str(tmdb_data.get("original_language") or "").lower()
    tmdb_type = tmdb_data.get("tmdb_media_type")
    omdb_type = str(pick_omdb(omdb_data, "Type") or "").lower()

    is_animation = "animation" in genres or "мульт" in genres or "anime" in genres
    if is_animation and original_language == "ja":
        return "Аниме"
    if is_animation:
        return "Мультфильм"
    if tmdb_type == "tv" or omdb_type in {"series", "episode"}:
        return "Сериал"
    return "Фильм"


def translate_omdb_genres(value: str | None) -> str:
    if not value or value == "N/A":
        return ""
    translated = []
    for genre in value.split(","):
        key = genre.strip().lower()
        translated.append(GENRE_TRANSLATIONS.get(key, key))
    return ", ".join(translated)


def pick_omdb(data: dict[str, Any], key: str) -> str | None:
    value = data.get(key)
    if not value or value == "N/A":
        return None
    return str(value)


def get_tmdb_imdb_id(detail: dict[str, Any], media_type: str) -> str | None:
    external_ids = detail.get("external_ids") or {}
    imdb_id = external_ids.get("imdb_id")
    if imdb_id:
        return imdb_id
    if media_type == "movie":
        return detail.get("imdb_id")
    return None


def get_tmdb_age(detail: dict[str, Any], media_type: str) -> str:
    if media_type == "movie":
        release_dates = (detail.get("release_dates") or {}).get("results", [])
        for country in ("RU", "US"):
            for item in release_dates:
                if item.get("iso_3166_1") != country:
                    continue
                for release in item.get("release_dates", []):
                    certification = release.get("certification")
                    age = normalize_age(certification)
                    if age:
                        return age
    else:
        ratings = (detail.get("content_ratings") or {}).get("results", [])
        for country in ("RU", "US"):
            for item in ratings:
                if item.get("iso_3166_1") == country:
                    age = normalize_age(item.get("rating"))
                    if age:
                        return age
    return ""


def normalize_age(value: str | None) -> str:
    if not value:
        return ""
    rating = value.strip().upper()
    if rating in {"N/A", "NOT RATED", "UNRATED"}:
        return ""
    age_match = re.search(r"(\d{1,2})\+?", rating)
    if age_match:
        return f"{age_match.group(1)}+"
    return RATING_TO_AGE.get(rating, "")


def format_iso_date(value: str | None) -> str:
    if not value:
        return ""
    try:
        return datetime.strptime(value, "%Y-%m-%d").strftime("%d.%m.%Y")
    except ValueError:
        return ""


def format_omdb_date(value: str | None) -> str:
    if not value:
        return ""
    for date_format in ("%d %b %Y", "%Y"):
        try:
            return datetime.strptime(value, date_format).strftime("%d.%m.%Y" if date_format != "%Y" else "%Y")
        except ValueError:
            continue
    return value


def as_int(value: str | None, default: int) -> int:
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return default


def clamp(value: int, low: int, high: int) -> int:
    return max(low, min(high, value))


def normalize_hex_color(value: str) -> tuple[int, int, int, int]:
    if not re.fullmatch(r"#[0-9A-Fa-f]{6}", value.strip()):
        value = "#FFFFFF"
    red = int(value[1:3], 16)
    green = int(value[3:5], 16)
    blue = int(value[5:7], 16)
    return red, green, blue, 255


def load_font(size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path("C:/Windows/Fonts/arialbd.ttf"),
        Path("C:/Windows/Fonts/arial.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def validate_poster_value(key: str, value: str) -> str:
    normalized = value.strip().lower()
    if key == "badge_text_color":
        if not re.fullmatch(r"#[0-9A-Fa-f]{6}", value):
            return "Цвет нужно указать в формате `#FFFFFF`."
        return ""

    if key == "badge_block_x" and normalized in {"right", "auto"}:
        return ""
    if key in {"badge_text_x", "badge_text_y"} and normalized == "auto":
        return ""

    if not re.fullmatch(r"\d{1,4}", value):
        return "Введите целое число."

    number = int(value)
    if key == "badge_block_opacity" and not 0 <= number <= 255:
        return "Прозрачность должна быть от 0 до 255."
    if key == "badge_text_size" and not 10 <= number <= 140:
        return "Размер текста должен быть от 10 до 140."
    return ""


def poster_value_prompt(key: str) -> str:
    label = POSTER_SETTING_LABELS[key]
    if key == "badge_text_color":
        return f"{label}: отправьте цвет в формате #FFFFFF."
    if key == "badge_block_x":
        return f"{label}: отправьте число в пикселях или `right` для правого угла."
    if key in {"badge_text_x", "badge_text_y"}:
        return f"{label}: отправьте число в пикселях или `auto` для автоматического выравнивания."
    if key == "badge_block_opacity":
        return f"{label}: отправьте число от 0 до 255."
    if key == "badge_text_size":
        return f"{label}: отправьте число от 10 до 140. Мини-блок расширится под текст автоматически."
    return f"{label}: отправьте число в пикселях."


def format_minutes(value: str) -> str:
    minutes = as_int(value, 10)
    labels = dict(SCHEDULE_INTERVALS)
    return labels.get(minutes, f"{minutes} мин")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def parse_admin_ids(value: str) -> list[int]:
    admin_ids = []
    for item in value.split(","):
        item = item.strip()
        if item and item.isdigit():
            admin_ids.append(int(item))
    return admin_ids


async def post_init(application: Application) -> None:
    bot: MovieBot = application.bot_data["movie_bot"]
    configure_schedule_job(application, bot)


def run() -> None:
    load_dotenv()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    instance_lock = SingleInstanceLock(BASE_DIR / ".bot_instance.lock")
    if not instance_lock.acquire():
        raise RuntimeError(
            "Бот уже запущен в другом окне/процессе на этом компьютере. "
            "Закройте старый python main.py и запустите снова."
        )
    atexit.register(instance_lock.release)

    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        raise RuntimeError("Set TELEGRAM_BOT_TOKEN in .env")

    db_path = Path(os.getenv("BOT_DB_PATH", "bot.sqlite3"))
    if not db_path.is_absolute():
        db_path = BASE_DIR / db_path

    db = Database(db_path)
    db.seed_admins(parse_admin_ids(os.getenv("ADMIN_IDS", "")))

    movie_bot = MovieBot(db)
    application = Application.builder().token(token).post_init(post_init).build()
    application.bot_data["movie_bot"] = movie_bot
    movie_bot.register(application)

    logging.info("Bot started")
    try:
        application.run_polling(allowed_updates=Update.ALL_TYPES)
    finally:
        instance_lock.release()


if __name__ == "__main__":
    try:
        run()
    except KeyboardInterrupt:
        pass
